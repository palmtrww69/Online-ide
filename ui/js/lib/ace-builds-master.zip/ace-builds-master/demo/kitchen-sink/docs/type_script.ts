TODO add a nice demo!
Try to keep it short!